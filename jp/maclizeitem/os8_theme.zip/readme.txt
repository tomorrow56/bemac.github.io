=========================================================================
[Name]      Desktop Theme like a "Macintosh OS8"
[Version]   Version 1.0
[Archive]   Os8_them.zip
[Copyright] Masao Yamazaki(KGG01125@niftyserve.or.jp)
[System]    Microsoft Windows95 + Microsoft Plus!
[Type]      Freeware
[Reproduction] Please send e-mail to me before reproducing.
=========================================================================

<Information>
  The URL of BeMac! HomePage is below.

    "http://hp.vector.co.jp/authors/VA008591/index.html"

<About this software>

  This is Desktop Theme like a "Macintosh OS8" for MIcrosoft Plus!

  "Os8_them.zip" is including these folder/files.

    readme.txt     --- This File(Read Me File-English)
    readme_j.txt   --- Read Me File(Japanese)
    Os8 Folder     --- Folder of Theme items

    OS8_1k.Theme   --- 1024*768 theme(English)
    OS8_800.Theme  --- 800*600  theme(English)
    OS8_640.Theme  --- 640*480  theme(English)

    OS8_1k_J.Theme --- 1024*768 theme(Japanese)
    OS8_800_J.Theme--- 800*600 theme(Japanese)
    OS8_640_J.Theme--- 640*480 theme(Japanese)

    logo_mac.bmp   --- Mac OS8 Start Up Screen(English)
    logow_mac.bmp  --- Mac OS8 Wait For Screen(English)
    logos_mac.bmp  --- Mac OS8 Turn Off Screen(English)

    logo_mac_J.bmp --- Mac OS8 Start Up Screen(Japanese)
    logow_mac_J.bmp--- Mac OS8 Wait Foe Screen(Japanese)
    logos_mac_J.bmp--- Mac OS8 Turn Off Screen(Japanese)

    BeMac Home Page--- Short Cut to BeMAC! Home Page

<How to use>

  Please copy these folder/files to "Microsoft Plus!" theme folder.
  (Defult is "C:\Program Files\Plus!\Themes\".)

    Os8 Folder     --- Folder of Theme items
    OS8_1k.Theme   --- 1024*768 theme(English)
    OS8_800.Theme  --- 800*600  theme(English)
    OS8_640.Theme  --- 640*480  theme(English)
    OS8_1k_J.Theme --- 1024*768 theme(Japanese)
    OS8_800_J.Theme--- 800*600 theme(Japanese)
    OS8_640_J.Theme--- 640*480 theme(Japanese)

  You can select Desktop Theme like a "Macintosh OS8" by using "Microsoft Plus!".

_/Masao Yamazaki_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
_/  e-mail:KGG01125@niftyserve.or.jp                            _/
_/  HOME PAGE;http://hp.vector.co.jp/authors/VA008591/(BeMAC!)  _/
_/            http://member.nifty.ne.jp/masa_yamazaki/(Others)  _/
_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

